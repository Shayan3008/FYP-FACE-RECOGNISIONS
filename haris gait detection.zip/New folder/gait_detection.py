import cv2 # Import the OpenCV library to enable computer vision
import numpy as np # Import the NumPy scientific computing library
from imutils.object_detection import non_max_suppression # Handle overlapping
from PIL import Image
from reid import REID
import os
# print(os.getcwd())
min_dist=10000
# from PIL import Image

import numpy as np
# from ipynb.fs.full.main import extract_features 
def calculate_distance(source, target):
    difference = abs(source-target)
    # print(difference.sum())
    return (pow((difference.sum())/600,2))

reid = REID()
def extract_features(reid, input):
    
    data = reid._features(input)
    return data
# Make sure the video file is in the same directory as your code
filename = 'test4.avi'
file_size = (1920,1080) # Assumes 1920x1080 mp4
scale_ratio = 1 # Option to scale to fraction of original size. 
 
# We want to save the output to a video file
fourcc = cv2.VideoWriter_fourcc('X','V','I','D')
result = cv2.VideoWriter("output9.avi", fourcc, 5.0, (1280,720))
output_filename = 'pedestrians_on_street.mp4'
output_frames_per_second = 20.0
image = []
image.append(np.array(Image.open('./test_134.jpg')))
# print(extract_features(image)[0])
temp=extract_features(reid, image)[0]
src = temp.data.cpu().numpy()
def main():
    
    
  # Create a HOGDescriptor object
  hog = cv2.HOGDescriptor()
     
  # Initialize the People Detector
  hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
     
  # Load a video
  cap = cv2.VideoCapture(filename)
 
  # Create a VideoWriter object so we can save the video output
  # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
  # result = cv2.VideoWriter(output_filename,  
  #                          fourcc, 
  #                          output_frames_per_second, 
  #                          file_size) 
     
  # Process the video
  while cap.isOpened():
         
    # Capture one frame at a time
    success, frame = cap.read() 
         
    # Do we have a video frame? If true, proceed.
    if success:
         
        # Resize the frame
      width = int(frame.shape[1] * scale_ratio)
      height = int(frame.shape[0] * scale_ratio)
      frame = cv2.resize(frame, (width, height))
             
      # Store the original frame
      orig_frame = frame.copy()
             
      # Detect people
      # image: a single frame from the video
      # winStride: step size in x and y direction of the sliding window
      # padding: no. of pixels in x and y direction for padding of 
      # sliding window
      # scale: Detection window size increase coefficient   
      # bounding_boxes: Location of detected people
      # weights: Weight scores of detected people
      # Tweak these parameters for better results
      (bounding_boxes, weights) = hog.detectMultiScale(frame, 
                                                       winStride=(16, 16),
                                                       padding=(4, 4), 
                                                       scale=1.05)
      temp2=[]
      bounding_box=[]
      # Draw bounding boxes on the framepixels
      for (x, y, w, h) in bounding_boxes:
           
            x, y = abs(x), abs(y)
            x2, y2 = x+w, y+h
            face = orig_frame[y:y2, x:x2]
            image = Image.fromarray(face)
            image = image.resize((160, 160))

            # image.save('images/test_'+str(x)+'.jpg')
            # image.show()
            # print(len((np.asarray(image)/255)))
            # image.show()
            print('image: ',image)
            temp2.append(np.array(image)/255)
            bounding_box.append((x,y,w,h))
            
      if len(temp2)>0:
        # print(temp2)
        dest=extract_features(reid, temp2)
        # print('dest: ', len(dest))
        selected_index = -1
        min_distance=10000
        for i in range(len(dest)):
          dist = calculate_distance(src, dest[i].data.cpu().numpy())
          print(dist)
          if dist < min_distance and dist < 1.9:
            selected_index = i
            min_distance = dist
        # print(selected_index)    

        cv2.rectangle(frame, 
          (bounding_box[selected_index][0], bounding_box[selected_index][1]),  
          (bounding_box[selected_index][0] + bounding_box[selected_index][2], bounding_box[selected_index][1] + bounding_box[selected_index][3]),  
          (0, 0, 255), 
            4)    
                       
      # Get rid of overlapping bounding boxes
      # You can tweak the overlapThresh value for better results
      bounding_boxes = np.array([[x, y, x + w, y + h] for (
                                x, y, w, h) in bounding_boxes])
             
      selection = non_max_suppression(bounding_boxes, 
                                      probs=None, 
                                      overlapThresh=0.45)
         
      # draw the final bounding boxes
      # for (x1, y1, x2, y2) in selection:
      #   cv2.rectangle(frame, 
      #                (x1, y1), 
      #                (x2, y2), 
      #                (0, 255, 0), 
      #                 4)
        
         
      # Write the frame to the output video file
      image = cv2.resize(frame, (1280,720))
    
      result.write(image)
             
      # Display the frame 
      # cv2.imshow("Frame", frame)    
 
      # Display frame for X milliseconds and check if q key is pressed
      # q == quit
      # if cv2.waitKey(25) & 0xFF == ord('q'):
      #   break
         
    # No more video frames left
    else:
      break
             
  # Stop when the video is finished
  cap.release()
     
  # Release the video recording
  result.release()
     
  # Close all windows
  cv2.destroyAllWindows() 
 
main()