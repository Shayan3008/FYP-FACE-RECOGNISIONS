from reid import REID
from PIL import Image
import numpy as np
reid = REID()

image = []
image.append(np.array(Image.open("test1.JPG")))
image.append(np.array(Image.open("test2.JPG")))
image.append(np.array(Image.open("test3.JPG")))
image.append(np.array(Image.open("test4.JPG")))
image.append(np.array(Image.open("img1.JPG")))
image.append(np.array(Image.open("img2.JPG")))

print(len(image))
data = reid._features(image)
src = data[0].data.cpu().numpy()
for i in range(1,len(image)):
    difference = abs(data[0].data.cpu().numpy()-data[i].data.cpu().numpy())
    # print(difference.sum())
    if ((difference.sum())/180) < 2.8:
        print("Same")
    else:
        print("different")